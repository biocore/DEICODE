# ----------------------------------------------------------------------------
# Copyright (c) 2016--, DEICODE development team.
#
# Distributed under the terms of the Modified BSD License.
#
# The full license is in the file COPYING.txt, distributed with this software.
#
# Biom to pandas dataframe code: Jamie Morton, gneiss, (2016), GitHub repository, https://github.com/biocore/gneiss
#
# ----------------------------------------------------------------------------

__version__ = "1.0.0"

from DEICODE import *
